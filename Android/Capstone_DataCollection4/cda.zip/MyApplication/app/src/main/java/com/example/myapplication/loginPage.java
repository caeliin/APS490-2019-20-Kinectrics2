package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;

public class loginPage extends AppCompatActivity {
    TextView loginName;
    TextView pw;
    TextView info;
    Button loginBton;
    TextView tv;

    int counter = 3;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        loginName = (TextView) findViewById(R.id.nameEditText);
        pw = (TextView) findViewById(R.id.pwEditText);
        info = (TextView) findViewById(R.id.infor);
        loginBton = (Button) findViewById(R.id.logInbutton);

        info.setText("Number of incorrect attempts: "+ String.valueOf(counter));

        loginBton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(loginName.getText().toString(),pw.getText().toString());
            }
        });

    }


    private void validate(String username, String pw){
        if((username.equals("Amin"))&& (pw.equals("1234"))){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else{
            counter--;

            info.setText("Number of incorrect attempts: "+ String.valueOf(counter));
            if(counter == 0){
                int second = 5;
                Timer t = new Timer();
                loginBton.setEnabled(false);


                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        String tag = "";
                        // This method will be executed once the timer is over
                        loginBton.setEnabled(true);
                        counter = 3;
                        Log.d(tag,"Wrong");
                        info.setText("Number of incorrect attempts: "+ String.valueOf(counter));

                    }
                },2000);
            }

        }
    }





}
