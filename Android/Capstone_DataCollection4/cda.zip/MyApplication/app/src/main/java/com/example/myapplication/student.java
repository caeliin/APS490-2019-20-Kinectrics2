package com.example.myapplication;

public class student {
    private int id, marks;
    private String name, surname;

    public student(){

    }

    public student(int id, String name, String surname, int marks){
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.marks = marks;
    }

    public int getID(){
        return this.id;
    }

    public String getName(){
        return this.name;
    }

    public String getSurname(){
        return this.surname;
    }

    public int getMarks(){
        return this.marks;
    }





}
