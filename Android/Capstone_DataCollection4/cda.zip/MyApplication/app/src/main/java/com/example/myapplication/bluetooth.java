package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class bluetooth extends AppCompatActivity {
    Button buttonOn, buttonOff,buttonShowPairedDevice,buttonShowDiscoveredDevice;
    ListView listDevice;
    BluetoothAdapter  myBluetoothAdapter;
    TextView nodevice;


    Intent btEnablingIntent;
    int requestCodeEnable;

    ArrayList<String> discoveredDevice= new  ArrayList<String>();
    ArrayAdapter<String> arrayAdapter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        buttonOn = (Button) findViewById(R.id.btn_bluethoothOn);
        buttonOff = (Button) findViewById(R.id.btn_bluetoothOff);
        buttonShowPairedDevice = (Button) findViewById(R.id.btn_showPariedDevice);
        buttonShowDiscoveredDevice = (Button) findViewById(R.id.btn_showDiscoverDevice);
        listDevice = (ListView) findViewById(R.id.listDevice);
        nodevice = (TextView) findViewById(R.id.nodevice);

        myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        btEnablingIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        requestCodeEnable = 1;//setting number greater than 0
        bluetoothOnMethod();
        bluetoothOffMethod();
        
        exeButtom();


        dicoverDevice();



    }

    /*
    method to discover nearby available Bluetooth devices
     */
    private void dicoverDevice() {
        buttonShowDiscoveredDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               myBluetoothAdapter.startDiscovery();



            }
        });
        IntentFilter intentFilter = new IntentFilter(BluetoothDevice.ACTION_FOUND);

        BroadcastReceiver myReciever = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();

                if(BluetoothDevice.ACTION_FOUND.equals(action)){
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    discoveredDevice.add(device.getName());
                    arrayAdapter.notifyDataSetChanged();
                }
            }
        };

        registerReceiver(myReciever,intentFilter);

        if(discoveredDevice.isEmpty()){
            nodevice.setText("No devices found");

        }

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,discoveredDevice);
        listDevice.setAdapter(arrayAdapter);



    }



    /*
    method to get list of the paired device name
     */
    private void exeButtom() {
        buttonShowPairedDevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Set<BluetoothDevice> bt = myBluetoothAdapter.getBondedDevices();
                String[] device =  new String[bt.size()];
                int index = 0;

                if(bt.size()>0){
                    for(BluetoothDevice dv : bt){
                        device[index] = dv.getName();
                        index++;
                    }

                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,device);
                    listDevice.setAdapter(arrayAdapter);

                }
            }
        });
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //check the requestCode
        if(requestCode == requestCodeEnable){
            if(resultCode == RESULT_OK){
                Toast.makeText(getApplicationContext(),"Bluetooth is Enable",Toast.LENGTH_LONG).show();

            }else if(resultCode == RESULT_CANCELED){
                Toast.makeText(getApplicationContext(),"Bluetooth Enabling Cancel",Toast.LENGTH_LONG).show();
            }
        }
    }

    private void bluetoothOnMethod() {
        buttonOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check the bluetooth support on the device or not
                if(myBluetoothAdapter == null){
                    Toast.makeText(getApplicationContext(),"Bluetooth does not support on this device",Toast.LENGTH_LONG).show();
                } else{
                    if(!myBluetoothAdapter.isEnabled()){
                        startActivityForResult(btEnablingIntent,requestCodeEnable);

                    }
                }
                /* Enable dicoverbility
                 * to enable the device discovered by other device*/
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,10); // set the dicoveravle time
                startActivity(intent);

            }
        });
    }

    private void bluetoothOffMethod() {
        buttonOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(myBluetoothAdapter == null){
                    Toast.makeText(getApplicationContext(),"Bluetooth does not support on this device",Toast.LENGTH_LONG).show();
                }
                else if(myBluetoothAdapter.isEnabled()){
                    myBluetoothAdapter.disable();
                }



            }
        });


    }



}
