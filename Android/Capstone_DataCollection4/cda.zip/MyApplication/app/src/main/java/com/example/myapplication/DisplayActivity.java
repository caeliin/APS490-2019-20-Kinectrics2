package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class DisplayActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    DatabaseHelper myDb;
    private TextView showTextName;
    private TextView showTextSurname;
    private TextView showmarks;
    private Spinner spinner;
    ArrayList<String> name = new ArrayList<String>();

    //String[] arraySpinner = new String[10];




    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        myDb = new DatabaseHelper(this);
        showTextName = findViewById(R.id.textView1);
        showTextSurname = findViewById(R.id.textView2);
        showmarks = findViewById(R.id.textView3);

        spinner = (Spinner) findViewById(R.id.spinner);
        name.add("View all");


        studentList();

        spinner.setOnItemSelectedListener(this);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, name);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);





    }


    //get all the data
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void studentList(){
        Cursor res = myDb.getAllData();
        if(res.getCount() == 0){
            return;
        }

        while(res.moveToNext()){
            name.add(res.getString(1));

        }

        name =  (ArrayList) name.stream().distinct().collect(Collectors.<String>toList());




    }

    public void getMarkByName(String name){
        Cursor res = myDb.getByKeyword(name);
        if(res.getCount() == 0){
            showTextName.setText("Error, Nothing found");
            return;
        }
        String nameText="";
        String surnameText = "";
        String marksText = "";

        while(res.moveToNext()){
            nameText =  nameText + "name: "+ res.getString(1) + "\n"+ "\n";
            surnameText = surnameText + "surname: "+ res.getString(2) + "\n"+ "\n";
            marksText = marksText + "marks: "+ res.getString(3) + "\n"+ "\n";

        }

        showTextName.setText(nameText);
        showTextSurname.setText(surnameText);
        showmarks.setText(marksText);



    }





    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (name.get(position).equals("View all")){

            Cursor res = myDb.getAllData();
            if(res.getCount() == 0){
                showTextName.setText("Error, Nothing found");
                return;
            }

            String nameText="";
            String surnameText = "";
            String marksText = "";
            int i = 0;

            while(res.moveToNext()){
                nameText =  nameText + "name: "+ res.getString(1) + "\n"+ "\n";
                surnameText = surnameText + "surname: "+ res.getString(2) + "\n"+ "\n";
                marksText = marksText + "marks: "+ res.getString(3) + "\n"+ "\n";

            }

            showTextName.setText(nameText);
            showTextSurname.setText(surnameText);
            showmarks.setText(marksText);
        }

        //Toast.makeText(getApplicationContext(),name.get(position), Toast.LENGTH_LONG).show();
        else{
            getMarkByName(spinner.getSelectedItem().toString());
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
